compras_lista = [('leite', 2), ('pringles', 25), ('batatas', 24),
                         ('cerveja', 2)]

for i in compras_lista:

    print(i[1])